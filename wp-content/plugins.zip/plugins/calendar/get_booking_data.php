<?php
define('WP_USE_THEMES', false);
require_once('../../../wp-load.php');

$jsonData = file_get_contents('php://input');
$data = json_decode($jsonData);

$dateStr = $data->date;

$dateTime = new DateTime($dateStr);

$formattedDate = $dateTime->format('Y-m-d');

global $wpdb;
$table_name_booking = $wpdb->prefix . 'booking_data'; 
$table_name_users = $wpdb->prefix . 'users';

$query = "SELECT bd.*, u.user_nicename
          FROM $table_name_booking bd
          LEFT JOIN $table_name_users u ON bd.user_id = u.ID
          WHERE bd.booking_details LIKE %s
          AND JSON_EXTRACT(bd.booking_details, '$.status') = '1'";

// Check if hidden_name is provided
if (!empty($data->hiddenName)) {
    $hiddenName = $data->hiddenName;
    $query .= $wpdb->prepare(" AND bd.user_id = %d", $hiddenName);
}

$query = $wpdb->prepare(
    $query,
    '%"datePicker":"%' . $formattedDate . '%"%'
);

$results = $wpdb->get_results($query, ARRAY_A);

header('Content-Type: application/json');
echo json_encode($results);

exit();
?>
