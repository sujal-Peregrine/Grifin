<?php
/*
Plugin Name: Custom Members Plugin
Description: A simple plugin to demonstrate Members integration.
Version: 1.0
Author: Island
*/

function enqueue_scripts()
{
    wp_enqueue_script('jquery');
    wp_enqueue_script('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js', array('jquery', 'popper'), '5.3.2', true);
    wp_enqueue_script('popper', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.10.2/umd/popper.min.js', array('jquery'), '2.10.2', true);
    wp_enqueue_script('datatables', 'https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js', array('jquery'), '1.11.5', true);
    wp_enqueue_style('bootstrap', plugin_dir_url(__FILE__) . '/bootstrap.min.css');
    wp_enqueue_style('datatables-style', 'https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css');
    wp_enqueue_script('zxcvbn', 'https://cdnjs.cloudflare.com/ajax/libs/zxcvbn/4.4.2/zxcvbn.js', array(), '4.4.2', true);
    wp_enqueue_script('password-strength-meter');
    wp_enqueue_style('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css');
    wp_enqueue_script('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', array('jquery'), null, true);
    wp_enqueue_script('flatpickr', 'https://cdn.jsdelivr.net/npm/flatpickr', array(), null, true);
    wp_enqueue_style('flatpickr', 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css');

}

add_action('admin_enqueue_scripts', 'enqueue_scripts');

// Add admin menu for members
function members_menu()
{
    add_menu_page(
        'Members',
        'Members',
        'manage_options',
        'members',
        'members_page'
    );

    add_submenu_page(
        'members',
        'Create Member',
        'Create Member',
        'manage_options',
        'create_member_page',
        'create_member_page'
    );

    add_submenu_page(
        null, // Set parent slug to null
        'Edit Member',
        'Edit Member',
        'manage_options',
        'edit_member_page',
        'edit_member_page'
    );

    add_submenu_page(
        null, // Set parent slug to null
        'View Member',
        'View Member',
        'manage_options',
        'view_member_page',
        'view_member_page'
    );
}


add_action('admin_menu', 'members_menu');




// Handle user creation
add_action('wp_ajax_create_member', 'create_member_callback');

function create_member_callback()
{
    // Sanitize and validate input data
    $first_name = sanitize_text_field($_POST['first_name']);
    $last_name = sanitize_text_field($_POST['last_name']);
    $username = sanitize_text_field($_POST['username']);
    $email = sanitize_email($_POST['email']);
    $password = sanitize_text_field($_POST['password']);
    $title = sanitize_text_field($_POST['title']); // Added line
    $description = sanitize_textarea_field($_POST['description']); // Added line
    $connected_members_raw = isset($_POST['connected_members']) ? $_POST['connected_members'] : array();
    $phone = sanitize_text_field($_POST['phone']);
    $summer_day_allocation = sanitize_text_field($_POST['summer_day_allocation']);
    $hunt_day_allocation = sanitize_text_field($_POST['hunt_day_allocation']);

    // Sanitize and validate each member ID
    $connected_members = array_map('intval', $connected_members_raw);
    $connected_members = array_filter($connected_members, 'absint');

    // Validate username and email
    if (empty($username) || empty($email) || !is_email($email) || email_exists($email) || username_exists($username)) {
        $response = array('success' => false, 'message' => 'Invalid username or email.');
        wp_send_json($response);
    }

    $user_id = wp_insert_user(
        array(
            'user_login' => $username,
            'user_email' => $email,
            'user_pass' => $password,
            'role' => 'club_member',
        )
    );

    if (is_wp_error($user_id)) {
        $response = array('success' => false, 'message' => 'Error creating user.');
    } else {
        // Save additional metadata for the created user
        update_user_meta($user_id, 'title', $title);
        update_user_meta($user_id, 'description', $description);
        update_user_meta($user_id, 'connected_members', $connected_members);
        update_user_meta($user_id, 'first_name', $first_name);
        update_user_meta($user_id, 'last_name', $last_name);
        update_user_meta($user_id, 'phone', $phone);
        update_user_meta($user_id, 'hunt_day_allocation', $hunt_day_allocation);
        update_user_meta($user_id, 'summer_day_allocation', $summer_day_allocation);

        $response = array('success' => true, 'message' => 'User created successfully.');
    }

    // Redirect the user
    $redirect_url = add_query_arg(array('create_user_message' => urlencode(json_encode($response))), admin_url('admin.php?page=members'));
    wp_redirect($redirect_url);
    exit;
}


add_action('admin_footer', 'initialize_select2');

function initialize_select2()
{
    ?>
    <script>
        jQuery(document).ready(function ($) {
            // Initialize Select2 for the connected_members dropdown
            $('#connected_members').select2();
        });
    </script>
    <?php
}


// Handle user edit
add_action('wp_ajax_edit_member', 'edit_member_callback');

function edit_member_callback()
{
    $first_name = sanitize_text_field($_POST['first_name']);
    $last_name = sanitize_text_field($_POST['last_name']);
    $username = sanitize_text_field($_POST['username']);
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    $email = sanitize_email($_POST['email']);
    $title = sanitize_text_field($_POST['title']);
    $phone = sanitize_text_field($_POST['phone']);
    $summer_day_allocation = sanitize_text_field($_POST['summer_day_allocation']);
    $hunt_day_allocation = sanitize_text_field($_POST['hunt_day_allocation']);
    $description = sanitize_textarea_field($_POST['description']);
    $connected_members_raw = isset($_POST['connected_members']) ? $_POST['connected_members'] : array();

    // Sanitize and validate each member ID
    $connected_members = array_map('intval', $connected_members_raw);
    $connected_members = array_filter($connected_members, 'absint');

    $user_data = get_userdata($user_id);

    // Validate user data
    if (!$user_data || !is_email($email)) {
        $response = array('success' => false, 'message' => 'Invalid user data.');
        wp_send_json($response);
    }

    // Update user data
    $user_update = wp_update_user(
        array(
            'ID' => $user_id,
            'user_email' => $email,
        )
    );

    // Save additional metadata for the edited user
    update_user_meta($user_id, 'title', $title);
    update_user_meta($user_id, 'description', $description);
    update_user_meta($user_id, 'connected_members', $connected_members);
    update_user_meta($user_id, 'first_name', $first_name);
    update_user_meta($user_id, 'last_name', $last_name);
    update_user_meta($user_id, 'phone', $phone);
    update_user_meta($user_id, 'hunt_day_allocation', $hunt_day_allocation);
    update_user_meta($user_id, 'summer_day_allocation', $summer_day_allocation);

    if (is_wp_error($user_update)) {
        $response = array('success' => false, 'message' => 'Error updating user.');
    } else {
        $response = array('success' => true, 'message' => 'User updated successfully.');
    }

    $redirect_url = add_query_arg(array('edit_user_message' => urlencode(json_encode($response)), 'user_id' => $user_id), admin_url('admin.php?page=members'));
    wp_redirect($redirect_url);
    exit;
}


add_action('admin_post_edit_member', 'edit_member_callback');
add_action('admin_post_nopriv_edit_member', 'edit_member_callback');


add_action('wp_ajax_delete_member', 'delete_member_callback');

function delete_member_callback()
{
    $member_id = intval($_POST['member_id']);
    $user = get_user_by('ID', $member_id);
    if ($user) {
        $result = wp_delete_user($member_id);
        if ($result) {
            $response = array('success' => true, 'message' => 'User deleted successfully.');
        } else {
            $response = array('success' => false, 'message' => 'Error deleting user.');
        }
    } else {
        $response = array('success' => false, 'message' => 'User not found.');
    }
    ob_clean();
    wp_send_json($response);
}

function members_page()
{
    global $wpdb;

    $table_name = $wpdb->users;

    $columns = array(
        'ID' => 'User ID',
        'user_login' => 'Username',
        'name' => 'Name',
        'user_email' => 'Email',
        'phone' => 'Phone',
        'user_registered' => 'Registration Date',
        'title' => 'Title',
        'description' => 'Description',
        'connected_members' => 'Connected Members',

    );

    $data = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT u.*
             FROM $wpdb->users u
             JOIN $wpdb->usermeta m ON u.ID = m.user_id
             WHERE m.meta_key = %s
               AND m.meta_value = %s
             ORDER BY u.ID DESC",
            'wp_capabilities',
            serialize(array('club_member' => true))
        )
    );



    ?>
    <style>
        #membersTable_paginate .paginate_button {
            margin: 0 5px;
            cursor: pointer;
            padding: 10px 15px;
            border-radius: 5px;
            color: #737373;
            border: 1px solid #ccc;
        }

        #membersTable_paginate .paginate_button.current {
            background-color: #007bff;
            color: #fff;
        }

        #membersTable thead th.sort {
            cursor: pointer;
        }

        #membersTable thead th.sort::after,
        #membersTable thead th.sort::before {
            content: '';
            display: inline-block;
            vertical-align: middle;
            /* margin-left: 5px; */
        }

        #membersTable thead th.sort {
            width: 50%;
            /* padding-right: 112px; */
            cursor: pointer;
            white-space: nowrap;
        }

        #membersTable thead th.sort::after {
            content: '\25B2';
        }

        #membersTable thead th.sort.desc::after {
            content: '\25BC';
        }

        #membersTable thead th.sort::after,
        #membersTable thead th.sort::before {
            color: #007bff;
            font-size: 12px;
            margin-top: -5px;
        }

        #membersTable thead th.sort.asc::after,
        #membersTable thead th.sort.desc::after {
            color: #ff0000;
            font-weight: bold;
        }

        .card {
            min-width: 100% !important;
            padding: 0
        }

        /* 
                                                    td {
                                                        display: flex;
                                                        align-items: center;
                                                    } */

        #membersTable_filter input[type="search"] {
            /* width: 68.5rem; */
            box-sizing: border-box;
            border: 0.2px solid #ccc;
            border-radius: 4px;
            /* margin-top: 10px; */
            margin-bottom: 5px;
            background: #f3f6f9;
        }

        .tooltip-inner {
            max-width: 200px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            cursor: pointer;
        }

        .table-responsive {
            overflow-y: hidden !important;
            /* overflow-x: hidden !important; */
        }

        #membersTable tbody tr {
            font-size: 15px;
            /* Adjust the font size as needed */
        }

        #membersTable thead th {
            font-size: 14px;
            white-space: nowrap;
            color: #878a99;
            font-weight: 400;
            line-height: 1.2;

            /* Adjust the font size as needed */
        }

        /* Set font size for table cells (td) */
        #membersTable tbody td {
            font-size: 13px;
            white-space: nowrap;
            line-height: 1.2;
            /* Adjust the font size as needed */
        }

        #membersTable tbody tr {
            line-height: 10px;
            /* Adjust the line height as needed */
        }

        #membersTable thead tr {
            line-height: 10px;
            /* Adjust the line height as needed */
        }

        .hr {
            opacity: 0.1;
        }

        .search {
            width: 100%;
            height: 40px;
            border-radius: 5px;
            border: 1px solid #ccc;
            padding: 0 10px;
            background-color: #f3f6f9;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .search input,
        .all input {
            width: 100%;
            outline: none !important;
            border: none !important;
            background-color: transparent;
        }

        .all select {
            width: 100%;
            outline: none !important;
            border: none !important;
            background-color: transparent;
        }

        .date input {
            width: 100%;
            height: 40px;
            border-radius: 5px;
            border: 1px solid #ccc;
            background-color: #f3f6f9;

        }

        .search-icon {
            width: 15px;
            opacity: 0.5;
        }



        .all {
            width: 100%;
            height: 40px;
            border-radius: 5px;
            border: 1px solid #ccc;
            padding: 0 10px;
            background-color: #f3f6f9;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .all img {
            width: 15px;
        }





        .image-container img {
            height: 100%;
            width: 100%;
            object-fit: contain;
        }



        .image-container {
            height: 25px;
            width: 25px;
            border-radius: 50%;
            overflow: hidden;
            cursor: pointer;

        }

        .text-overlay {
            text-align: center;
            background: #000;
            color: #fff;
            position: absolute;
            top: -45%;
            border-radius: 5px;
            margin-left: -1rem;
            clip-path: polygon(0% 0%, 100% 0%, 100% 75%, 65% 75%, 49% 100%, 30% 75%, 0% 75%);
            padding: 11px 10px;
            opacity: 0;
            transition: opacity 0.3s ease-in-out;
        }

        .text-overlay p {
            margin-bottom: 5px;
        }

        .image-container:hover .text-overlay {
            opacity: 1;
        }

        .more {
            height: 25px;
            width: 25px;
            border-radius: 50%;
            background-color: #6691e7;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }

        .more h4 {
            margin-bottom: 0;
            color: #fff;
            font-size: 13px;
            font-weight: 600;
        }

        .inline-block-style {
            display: inline-block;
            vertical-align: top;
            /* Adjust as needed */
        }

        #membersTable_paginate{
            position: absolute;
            bottom: 5%;
            right: 0;
        }
    </style>

    <body>

        <div class="card" id="tasksList">
            <div class="card-header border-0 pb-0">
                <div class="d-flex align-items-center">
                    <h5 class="card-title mb-0 flex-grow-1">Members List</h5>
                    <div class="flex-shrink-0">
                        <div class="d-flex flex-wrap gap-2">
                            <a class="btn btn-secondary"
                                href="<?php echo admin_url('admin.php?page=create_member_page'); ?>">New User +</a>
                        </div>
                    </div>
                </div>
            </div>
            <hr class="hr">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="search">
                            <img class="search-icon"
                                src="https://uxwing.com/wp-content/themes/uxwing/download/user-interface/search-icon.png"
                                alt="">
                            <input type="text" placeholder="Search for tasks or something...">
                        </div>
                    </div>
                    <div class="col date">
                        <input type="text" id="datepicker" placeholder="Select date range">
                    </div>
                    <div class="col">
                        <div class="all">
                            <!-- <input type="text" placeholder="All"> -->
                            <select id="filter_members" name="filter_members[]" multiple>
                                <?php
                                $users = get_users();
                                foreach ($users as $user) {
                                    echo '<option value="' . esc_attr($user->ID) . '">' . esc_html($user->display_name) . '</option>';
                                }
                                ?>
                            </select>
                            <img src="https://static.thenounproject.com/png/1123247-200.png" alt="">

                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body" style="height: 100%;">
                <div class="table-responsive table-card mb-0 pb-3">
                    <table class="table align-middle table-nowrap mb-0 " id="membersTable">
                        <thead class="table-light text-muted ">
                            <tr>
                                <?php foreach ($columns as $column_key => $column_name): ?>
                                    <th class="sort" data-column="<?php echo $column_key; ?>">
                                        <?php echo $column_name; ?>
                                    </th>
                                <?php endforeach; ?>
                                <th class="action-column">Action</th>
                                <!-- <th>Assigned To</th>
                                <th>Status</th> -->


                            </tr>
                        </thead>
                        <tbody class="list form-check-all">
                            <?php foreach ($data as $row): ?>
                                <tr>
                                    <?php foreach ($columns as $column_key => $column_name): ?>
                                        <td data-column="<?php echo $column_key; ?>" class="position-relative">
                                            <?php
                                            if ($column_key === 'user_login') {
                                                echo '<a href="' . admin_url('admin.php?page=edit_member_page&user_id=' . $row->ID) . '">' . $row->$column_key . '</a>';
                                            } elseif ($column_key === 'user_registered') {
                                                echo date('d M, Y', strtotime($row->$column_key));
                                            } elseif ($column_key === 'connected_members') {
                                                $connected_member_ids = get_user_meta($row->ID, 'connected_members', true);
                                                if (!empty($connected_member_ids)) {
                                                    // Display the first two connected members
                                                    $count = min(2, count($connected_member_ids));
                                                    for ($i = 0; $i < $count; $i++) {
                                                        $user_id = $connected_member_ids[$i];
                                                        $user_login = get_user_by('ID', $user_id)->user_login;
                                                        echo '<div class="image-container inline-block-style">';
                                                        echo '<img src="https://themesbrand.com/velzon/html/creative/assets/images/users/avatar-7.jpg" alt="Your Image">';
                                                        echo '<div class="text-overlay">';
                                                        echo "<p>{$user_login}</p>";
                                                        echo '</div>';
                                                        echo '</div>';
                                                    }

                                                    // Show the count for the remaining connected members
                                                    $remaining_count = max(0, count($connected_member_ids) - $count);
                                                    if ($remaining_count > 0) {
                                                        echo '<div class="more inline-block-style">';
                                                        echo "<h4 style='position:absolute;left:65px;bottom: 24px;'>{$remaining_count}+</h4>";
                                                        echo '</div>';
                                                    }
                                                } else {
                                                    echo 'None';
                                                }
                                            } elseif ($column_key === 'description') {

                                                $description = esc_html(get_user_meta($row->ID, 'description', true));
                                                $words = explode(' ', $description);
                                                $word_count = count($words);

                                                if ($word_count > 10) {
                                                    $short_description = implode(' ', array_slice($words, 0, 5));
                                                    $full_description = implode(' ', array_slice($words, 5));

                                                    echo '<span class="show-more" data-full-description="' . $description . '">' . $short_description . '... <a href="#">Show More</a></span>';
                                                } else {
                                                    echo $description;
                                                }
                                            } elseif ($column_key === 'title') {
                                                echo esc_html(get_user_meta($row->ID, 'title', true));
                                            } elseif ($column_key === 'phone') {
                                                echo esc_html(get_user_meta($row->ID, 'phone', true));
                                            } elseif ($column_key === 'name') {
                                                $firstname = esc_html(get_user_meta($row->ID, 'first_name', true));
                                                $lastname = esc_html(get_user_meta($row->ID, 'last_name', true));
                                                echo '<a href="' . admin_url('admin.php?page=view_member_page&user_id=' . $row->ID) . '">' . $firstname . ' ' . $lastname . '</a>';
                                                // echo esc_html(get_user_meta($row->ID, 'first_name', true));
                                
                                            } elseif (property_exists($row, $column_key)) {
                                                echo $row->$column_key;
                                            } else {
                                                echo '';
                                            }


                                            ?>

                                        </td>
                                    <?php endforeach; ?>

                                    <td style="display: flex;
    align-items: center;">
                                        <button class="btn delete-member" data-member-id="<?php echo $row->ID; ?>">
                                            <i class="fa fa-trash" aria-hidden="true"></i>
                                        </button>

                                        <?php foreach ($columns as $column_key => $column_name): ?>
                                            <?php

                                            if ($column_key === 'user_login') {
                                                echo '<a href="' . admin_url('admin.php?page=view_member_page&user_id=' . $row->ID) . '"><i class="fa fa-eye" style="color: black;" aria-hidden="true"></i></a>';
                                            }
                                            ?>
                                        <?php endforeach; ?>
                                    </td>



                                </tr>
                            <?php endforeach; ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- Add this HTML markup where you want to display the Bootstrap modal -->
        <div id="descriptionModal" class="modal fade" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <!-- Content will be dynamically inserted here -->
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </body>

    <script>
        var table;

        jQuery(document).ready(function ($) {
            var table = $('#membersTable').dataTable({
                searching: false,
                order: [[0, 'desc']], // Assuming the user ID column is at index 0 in your table
            });


            // Initialize Bootstrap tooltip
            // $('[data-bs-toggle="tooltip"]').tooltip();

            // Click event for show-more
            $('.show-more').on('click', function (event) {
                event.preventDefault();
                var fullDescription = $(this).data('full-description');
                // Set the content of the modal dynamically
                $('#descriptionModal').find('.modal-body').html(fullDescription);
                // Show the modal
                $('#descriptionModal').modal('show');
            });

            // Click event for delete-member
            $('.delete-member').on('click', function () {
                var member_id = $(this).data('member-id');

                var confirmDelete = confirm("Are you sure you want to delete this user?");
                if (!confirmDelete) {
                    return;
                }

                $.ajax({
                    type: 'POST',
                    url: ajaxurl,
                    data: {
                        action: 'delete_member',
                        member_id: member_id,
                    },
                    success: function (response) {
                        try {
                            window.location.href = "<?php echo admin_url('admin.php?page=members'); ?>";
                        } catch (error) {
                            console.error("Invalid JSON response:", response);
                        }
                    }
                });
            });

            flatpickr("#datepicker", {
                dateFormat: 'Y-m-d', // Adjust the date format as needed
                onChange: function (selectedDates, dateStr, instance) {
                    filterByDate(dateStr);
                }
            });

            // Function to filter the table based on the selected date
            function filterByDate(selectedDate) {

            }

            $('#filter_members').select2();

        });
    </script>

    <?php
}

//Create Page

function view_member_page()
{
    $user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
    $user_data = get_userdata($user_id);
    $connected_members = get_user_meta($user_id, 'connected_members', true);

    ?>
    <style>
        .card {
            min-width: 100% !important;
        }

        .connected-members-card {
            margin-top: 20px;
        }
    </style>

    <div class="wrap">
        <!-- First Card: User Information -->
        <div class="card">
            <div class="card-header border-0">
                <div class="d-flex align-items-center">
                    <h5 class="card-title mb-0 flex-grow-1">View Member Details</h5>
                    <div class="flex-shrink-0">
                        <div class="d-flex flex-wrap gap-2">
                            <a class="btn btn-secondary"
                                href="<?php echo esc_url(admin_url('admin.php?page=members')); ?>">Members List</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php if ($user_data): ?>

                    <table class="table">
                        <tr>
                            <td><strong>Username:</strong></td>
                            <td>
                                <?php echo esc_html($user_data->user_login); ?>
                            </td>
                        </tr>
                        <tr>
                            <td><strong>First Name:</strong></td>
                            <td>
                                <?php echo esc_html(get_user_meta($user_id, 'first_name', true)); ?>
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Last Name:</strong></td>
                            <td>
                                <?php echo esc_html(get_user_meta($user_id, 'last_name', true)); ?>
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Email:</strong></td>
                            <td>
                                <?php echo esc_attr($user_data->user_email); ?>
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Phone:</strong></td>
                            <td>
                                <?php echo esc_attr(get_user_meta($user_id, 'phone', true)); ?>
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Password</strong></td>

                            <td>
                                <a href="<?php echo esc_url(wp_lostpassword_url()); ?>">Reset Password</a>
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Title:</strong></td>
                            <td>
                                <?php echo esc_html(get_user_meta($user_id, 'title', true)); ?>
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Total Hunt Day Allocation:</strong></td>
                            <td>
                                <?php echo esc_html(get_user_meta($user_id, 'hunt_day_allocation', true)); ?>
                            </td>
                        </tr>

                    </table>

                <?php else: ?>
                    <div class="alert alert-danger" role="alert">
                        <p>User not found.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Second Card: Connected Members -->
        <?php if (!empty($connected_members)): ?>
            <div class="connected-members-card card">
                <div class="card-header border-0">
                    <div class="d-flex align-items-center">
                        <h5 class="card-title mb-0 flex-grow-1">Connected Members</h5>
                        <div class="flex-shrink-0">

                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (!empty($connected_members)): ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Username</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Title</th>
                                    <th>Total Hunt Day Allocation:</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($connected_members as $connected_member_id): ?>
                                    <?php
                                    $connected_member = get_user_by('ID', $connected_member_id);
                                    $connected_username = $connected_member->user_login;
                                    $connected_first_name = get_user_meta($connected_member_id, 'first_name', true);
                                    $connected_last_name = get_user_meta($connected_member_id, 'last_name', true);
                                    $connected_title = get_user_meta($connected_member_id, 'title', true);
                                    $connected_hunt_day_allocation = get_user_meta($connected_member_id, 'hunt_day_allocation', true);
                                    ?>
                                    <tr>
                                        <td style="<?php echo empty($connected_username) ? 'color: red;' : ''; ?>">
                                            <?php if (empty($connected_username)): ?>
                                                <i>NULL</i>
                                            <?php else: ?>
                                                <a
                                                    href="<?php echo esc_url(admin_url('admin.php?page=view_member_page&user_id=' . $connected_member_id)); ?>">
                                                    <?php echo esc_html($connected_username); ?>

                                                </a>
                                            <?php endif; ?>
                                        </td>
                                        <td style="<?php echo empty($connected_first_name) ? 'color: red;' : ''; ?>">
                                            <?php echo empty($connected_first_name) ? '<i>NULL</i>' : esc_html($connected_first_name); ?>
                                        </td>
                                        <td style="<?php echo empty($connected_last_name) ? 'color: red;' : ''; ?>">
                                            <?php echo empty($connected_last_name) ? '<i>NULL</i>' : esc_html($connected_last_name); ?>
                                        </td>
                                        <td style="<?php echo empty($connected_title) ? 'color: red;' : ''; ?>">
                                            <?php echo empty($connected_title) ? '<i>NULL</i>' : esc_html($connected_title); ?>
                                        </td>
                                        <td style="<?php echo empty($connected_hunt_day_allocation) ? 'color: red;' : ''; ?>">
                                            <?php echo empty($connected_hunt_day_allocation) ? '<i>NULL</i>' : esc_html($connected_hunt_day_allocation); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p>No connected members.</p>
                    <?php endif; ?>
                </div>

            </div>
        <?php endif; ?>
    </div>
    <script>
        jQuery(document).ready(function ($) {
            $('#phone').on('input', function () {
                var phone = $(this).val();

                // Remove non-digit characters
                phone = phone.replace(/\D/g, '');

                // Restrict to a maximum of 10 digits
                if (phone.length > 10) {
                    phone = phone.slice(0, 10);
                    $(this).val(phone);
                }

                // Display error message if phone number is not valid
                if (phone.length !== 10) {
                    $('#phoneError').text('Please enter a valid 10-digit phone number');
                } else {
                    $('#phoneError').text('');
                }
            });
        });
    </script>

    <?php
}


function create_member_page()
{
    ?>
    <style>
        .card {
            min-width: 100% !important;
        }

        .mem-form input {
            border: 1px solid #d9dfff;
            height: 35px;
            box-shadow: 0 0 1px #00000026;
        }

        .mem-form label {
            font-size: 13px;
            text-shadow: 0 0 5px #00000026;
        }
    </style>
    <div class="card">
        <div class="card-header border-0">
            <div class="d-flex align-items-center">
                <h5 class="card-title mb-0 flex-grow-1">Create Member</h5>
                <div class="flex-shrink-0">
                    <div class="d-flex flex-wrap gap-2">
                        <a class="btn btn-secondary" href="<?php echo esc_url(admin_url('admin.php?page=members')); ?>">User
                            List</a>


                    </div>
                </div>
            </div>
        </div>
        <div class="card-body">
            <form class="mem-form" id="userCreationForm" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"
                method="post">
                <input type="hidden" name="action" value="create_member">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="first_name" class="form-label">First Name:</label>
                        <input type="text" id="first_name" name="first_name" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label for="last_name" class="form-label">Last Name:</label>
                        <input type="text" id="last_name" name="last_name" class="form-control" required>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="username" class="form-label">Username:</label>
                        <input type="text" id="username" name="username" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label for="email" class="form-label">Email:</label>
                        <input type="email" id="email" name="email" class="form-control" required>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-12">
                        <label for="password" class="form-label">Password:</label>
                        <div class="input-group">
                            <button type="button" id="generatePassword" class="btn btn-secondary">Generate Password</button>
                            <input type="text" id="password" name="password" class="form-control password-input"
                                autocomplete="new-password" required>
                            <button type="button" class="btn btn-outline-secondary show-password"
                                style="display: none;">Show</button>
                            <button type="button" class="btn btn-outline-primary hide-password">Hide</button>
                        </div>
                        <small id="passwordHelp" class="form-text text-muted"></small>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="phone" class="form-label">Phone:</label>
                    <input type="number" id="phone" name="phone" class="form-control" required>
                    <span class="error" id="phoneError"></span>
                </div>

                <div class="mb-3">
                    <label for="title" class="form-label">Title:</label>
                    <input type="text" id="title" name="title" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label">Description:</label>
                    <textarea id="description" name="description" class="form-control" rows="2"
                        style="border: 1px solid #ced4da;" required></textarea>
                </div>

                <div class="row mb-3">

                    <div class="col-md-6">
                        <label for="hunt_day_allocation" class="form-label">Total Hunt Day Allocation:</label>
                        <input type="number" id="hunt_day_allocation" name="hunt_day_allocation"
                            class="form-control allocation" required min="0" max="50">
                        <span class="error">(0-50)</span>
                    </div>

                    <div class="col-md-6">
                        <label for="summer_day_allocation" class="form-label">Total Summer Day Allocation:</label>
                        <input type="number" id="summer_day_allocation" name="summer_day_allocation"
                            class="form-control allocation" required min="0" max="50">
                        <span class="error">(0-50)</span>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-12">
                        <label for="connected_members" class="form-label">Connected Members:</label><br>
                        <select id="connected_members" name="connected_members[]" class="form-control select2" multiple>
                            <?php
                            $users = get_users();
                            foreach ($users as $user) {
                                echo '<option value="' . esc_attr($user->ID) . '">' . esc_html($user->display_name) . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-success">Submit</button>
            </form>
        </div>
    </div>
    <script>
        jQuery(document).ready(function ($) {

            $('#membersTable').DataTable(
                {
                    "dom": '<"dt-buttons"Bf><"clear">lirtp',
                    "paging": true,
                    "autoWidth": true,
                    "buttons": [
                        'colvis',
                        'copyHtml5',
                        'csvHtml5',
                        'excelHtml5',
                        'pdfHtml5',
                        'print'
                    ]
                }
            );

            $('.allocation').on('input', function () {
                var enteredValue = $(this).val();

                // Validate the entered value
                if (enteredValue < 0) {
                    // Restrict to the minimum value of 0
                    $(this).val(0);
                } else if (enteredValue > 50) {
                    // Restrict to the maximum value of 50
                    $(this).val(50);
                }
            });



            $('#phone').on('input', function () {
                var phone = $(this).val();

                // Remove non-digit characters
                phone = phone.replace(/\D/g, '');

                // Restrict to a maximum of 10 digits
                if (phone.length > 10) {
                    phone = phone.slice(0, 10);
                    $(this).val(phone);
                }

                // Display error message if phone number is not valid
                if (phone.length !== 10) {
                    $('#phoneError').text('Please enter a valid 10-digit phone number');
                } else {
                    $('#phoneError').text('');
                }
            });

            $('#generatePassword').on('click', function () {
                var generatedPassword = generateRandomPassword();
                $('#password').val(generatedPassword);
                updatePasswordStrength(generatedPassword);
            });
            $(".show-password, .hide-password").on('click', function () {
                var passwordField = $("#password");
                var passwordType = passwordField.attr('type');

                if (passwordType === 'password') {
                    passwordField.attr("type", "text");
                    $(".show-password").hide();
                    $(".hide-password").show();
                } else {
                    passwordField.attr("type", "password");
                    $(".hide-password").hide();
                    $(".show-password").show();
                }
            });

            $('#password').on('input', function () {
                var password = $(this).val();

                updatePasswordStrength(password);
            });

            $('#togglePassword').on('click', function () {
                var passwordField = $('#password');
                var passwordType = passwordField.attr('type');
                passwordField.attr('type', passwordType === 'password' ? 'text' : 'password');
            });

            $('#userCreationForm').on('submit', function (e) {
                e.preventDefault();

                var username = $('#username').val();
                var first_name = $('#first_name').val();
                var last_name = $('#last_name').val();
                var email = $('#email').val();
                var password = $('#password').val();
                var title = $('#title').val();
                var description = $('#description').val();

                var connectedMembers = $('#connected_members').val();
                var phone = $('#phone').val();
                var hunt_day_allocation = $('#hunt_day_allocation').val();
                var summer_day_allocation = $('#summer_day_allocation').val();

                $.ajax({
                    type: 'POST',
                    url: ajaxurl,
                    data: {
                        action: 'create_member',
                        username: username,
                        email: email,
                        password: password,
                        title: title,
                        description: description,
                        connected_members: connectedMembers,
                        first_name: first_name,
                        last_name: last_name,
                        phone: phone,
                        hunt_day_allocation: hunt_day_allocation,
                        summer_day_allocation: summer_day_allocation,
                    },
                    success: function (response) {
                        console.log(response);
                        window.location.href = "<?php echo esc_url(admin_url('admin.php?page=members')); ?>";
                    }
                });
            });


            function generateRandomPassword() {
                var length = 12;
                var charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+";
                var password = "";

                // Ensure at least one character from each category
                var uppercaseChar = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                var lowercaseChar = "abcdefghijklmnopqrstuvwxyz";
                var numberChar = "0123456789";
                var symbolChar = "!@#$%^&*()_+";

                password += getRandomChar(uppercaseChar);
                password += getRandomChar(lowercaseChar);
                password += getRandomChar(numberChar);
                password += getRandomChar(symbolChar);

                // Fill the remaining characters randomly
                for (var i = 4; i < length; i++) {
                    password += charset.charAt(Math.floor(Math.random() * charset.length));
                }

                // Shuffle the password characters for better randomness
                password = password.split('').sort(function () {
                    return 0.5 - Math.random();
                }).join('');

                return password;
            }

            function getRandomChar(charset) {
                return charset.charAt(Math.floor(Math.random() * charset.length));
            }


            function updatePasswordStrength(password) {
                var strength = calculatePasswordStrength(password);
                var strengthText = getStrengthText(strength);
                var feedbackColor = getStrengthColor(strength);
                $('#passwordHelp').text('Password Strength: ' + strengthText).css('color', feedbackColor);
            }

            function calculatePasswordStrength(password) {
                // Check for various password criteria and assign a strength value
                var length = password.length;
                var hasUpperCase = /[A-Z]/.test(password);
                var hasLowerCase = /[a-z]/.test(password);
                var hasNumbers = /\d/.test(password);
                var hasSymbols = /[!@#$%^&*()_+]/.test(password);

                // Assign a strength value based on the criteria
                if (length < 8 || !(hasUpperCase && hasLowerCase && hasNumbers && hasSymbols)) {
                    return 1; // Weak
                } else if (length < 12) {
                    return 2; // Medium
                } else {
                    return 3; // Strong
                }
            }

            function getStrengthText(strength) {
                switch (strength) {
                    case 1:
                        return 'Weak';
                    case 2:
                        return 'Medium';
                    case 3:
                        return 'Strong';
                    default:
                        return '';
                }
            }

            function getStrengthColor(strength) {
                switch (strength) {
                    case 1:
                        return 'red'; // Weak
                    case 2:
                        return 'orange'; // Medium
                    case 3:
                        return 'green'; // Strong
                    default:
                        return '';
                }
            }
        });
    </script>

    <?php
}

//Edit Page
// Edit Member Page
function edit_member_page()
{
    ?>
    <style>
        .card {
            min-width: 100% !important;
        }
    </style>

    <div class="wrap">
        <div class="card">
            <div class="card-header border-0">
                <div class="d-flex align-items-center">
                    <h5 class="card-title mb-0 flex-grow-1">Edit Member Details</h5>
                    <div class="flex-shrink-0">
                        <div class="d-flex flex-wrap gap-2">
                            <a class="btn btn-secondary"
                                href="<?php echo esc_url(admin_url('admin.php?page=members')); ?>">Members List</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php
                $user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
                $user_data = get_userdata($user_id);

                if ($user_data):
                    $registration_date = get_user_meta($user_id, 'user_registered', true);
                    $connected_members = get_user_meta($user_id, 'connected_members', true);
                    ?>
                    <form id="userEditForm" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
                        <input type="hidden" name="action" value="edit_member">
                        <input type="hidden" name="user_id" value="<?php echo esc_attr($user_id); ?>">


                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="first_name" class="form-label">First Name:</label>
                                <input type="text" id="first_name" name="first_name" class="form-control"
                                    value="<?php echo esc_html(get_user_meta($user_id, 'first_name', true)); ?>" required>
                            </div>

                            <div class="col-md-6">
                                <label for="last_name" class="form-label">Last Name:</label>
                                <input type="text" id="last_name" name="last_name" class="form-control"
                                    value="<?php echo esc_html(get_user_meta($user_id, 'last_name', true)); ?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="user_login" class="form-label">User Name:</label>
                                <input type="text" id="user_login" name="user_login"
                                    value="<?php echo esc_attr($user_data->user_login); ?>" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label for="email" class="form-label">Email:</label>
                                <input type="email" id="email" name="email"
                                    value="<?php echo esc_attr($user_data->user_email); ?>" class="form-control" required>
                            </div>
                        </div>




                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label for="phone" class="form-label">Phone</label>
                                <input type="text" id="phone" name="phone" class="form-control"
                                    value="<?php echo esc_html(get_user_meta($user_id, 'phone', true)); ?>" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="title" class="form-label">Title:</label>
                            <input type="text" id="title" name="title" class="form-control"
                                value="<?php echo esc_html(get_user_meta($user_id, 'title', true)); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="description" class="form-label">Description:</label>
                            <textarea id="description" name="description" class="form-control" rows="2"
                                style="border: 1px solid #ced4da;"
                                required><?php echo esc_html(get_user_meta($user_id, 'description', true)); ?></textarea>
                        </div>


                        <div class="row mb-3">

                            <div class="col-md-6">
                                <label for="hunt_day_allocation" class="form-label">Total Hunt Day Allocation:</label>
                                <input type="number" id="hunt_day_allocation" name="hunt_day_allocation"
                                    class="form-control allocation" required min="0" max="50"
                                    value="<?php echo esc_html(get_user_meta($user_id, 'hunt_day_allocation', true)); ?>">
                                <span class="error">(0-50)</span>
                            </div>

                            <div class="col-md-6">
                                <label for="summer_day_allocation" class="form-label">Total Summer Day Allocation:</label>
                                <input type="number" id="summer_day_allocation" name="summer_day_allocation"
                                    class="form-control allocation" required min="0" max="50"
                                    value="<?php echo esc_html(get_user_meta($user_id, 'summer_day_allocation', true)); ?>">
                                <span class="error">(0-50)</span>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="connected_members" class="form-label">Connected Members:</label><br>
                            <select id="connected_members" name="connected_members[]" class="form-control" multiple>
                                <?php
                                if (!is_array($connected_members)) {
                                    $connected_members = array();
                                }

                                $all_users = get_users();
                                foreach ($all_users as $user) {
                                    $selected = in_array($user->ID, $connected_members) ? 'selected' : '';
                                    echo '<option value="' . esc_attr($user->ID) . '" ' . $selected . '>' . esc_html($user->user_login) . '</option>';
                                }
                                ?>
                            </select>
                        </div>

                        <button type="submit" class="btn btn-success">Update</button>
                        <a class="btn btn-primary" href="<?php echo esc_url(wp_lostpassword_url()); ?>">Reset Password</a>

                    </form>
                <?php else: ?>
                    <div class="alert alert-danger" role="alert">
                        <p>User not found.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        jQuery(document).ready(function ($) {
            // Initialize select2 for multiple selection
            $('#connected_members').select2();
            $('.allocation').on('input', function () {
                var enteredValue = $(this).val();

                // Validate the entered value
                if (enteredValue < 0) {
                    // Restrict to the minimum value of 0
                    $(this).val(0);
                } else if (enteredValue > 50) {
                    // Restrict to the maximum value of 50
                    $(this).val(50);
                }
            });

            $('#phone').on('input', function () {
                var phone = $(this).val();

                // Remove non-digit characters
                phone = phone.replace(/\D/g, '');

                // Restrict to a maximum of 10 digits
                if (phone.length > 10) {
                    phone = phone.slice(0, 10);
                    $(this).val(phone);
                }

                // Display error message if phone number is not valid
                if (phone.length !== 10) {
                    $('#phoneError').text('Please enter a valid 10-digit phone number');
                } else {
                    $('#phoneError').text('');
                }
            });
        });
    </script>
    <?php
}

add_action('admin_post_create_member', 'create_member_callback');
add_action('admin_post_nopriv_create_member', 'create_member_callback');


// Add the menu item in the admin menu
function add_club_member_menu_item()
{
    if (current_user_can('club_member')) {
        add_menu_page(
            'Member Profile',
            'Member Profile',
            'club_member', // Capability required to access the menu item
            'club_members_page', // Menu slug
            'club_members_page_callback', // Callback function to display the page
            'dashicons-groups', // Icon for the menu item
            20 // Position in the menu
        );
    }
}

// Callback function to display the page content
// function club_members_page_callback() {
//     // Your page content goes here
//     echo '<div class="wrap"><h1>Club Members</h1><p>This is the content of the Club Members page.</p></div>';
// }

function club_members_page_callback()
{
    $user_id = get_current_user_id();
    $user_data = get_userdata($user_id);
    $connected_members = get_user_meta($user_id, 'connected_members', true);
    if (isset($_POST['update_profile'])) {
        // Get the updated values from the form
        $new_email = sanitize_email($_POST['new_email']);
        $new_phone = sanitize_text_field($_POST['new_phone']);

        // Update the user's email and phone
        wp_update_user(array('ID' => $user_id, 'user_email' => $new_email));
        update_user_meta($user_id, 'phone', $new_phone);

        // Refresh the user data after the update
        $user_data = get_userdata($user_id);
    }
    ?>
    <style>
        .card {
            min-width: 100% !important;
        }

        .connected-members-card {
            margin-top: 20px;
        }
    </style>

    <div class="wrap">
        <!-- First Card: User Information -->
        <div class="card">
            <div class="card-header border-0">
                <div class="d-flex align-items-center">
                    <h5 class="card-title mb-0 flex-grow-1">Member Details</h5>
                    <div class="flex-shrink-0">

                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php if ($user_data): ?>
                    <form method="post" action="">

                        <table class="table">
                            <tr>
                                <td><strong>Username:</strong></td>
                                <td>
                                    <?php echo esc_html($user_data->user_login); ?>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>First Name:</strong></td>
                                <td>
                                    <?php echo esc_html(get_user_meta($user_id, 'first_name', true)); ?>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Last Name:</strong></td>
                                <td>
                                    <?php echo esc_html(get_user_meta($user_id, 'last_name', true)); ?>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Email:</strong></td>
                                <td>
                                    <input type="email" name="new_email" value="<?php echo esc_attr($user_data->user_email); ?>"
                                        required>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Phone:</strong></td>
                                <td>
                                    <input type="number" name="new_phone" id="phone"
                                        value="<?php echo esc_attr(get_user_meta($user_id, 'phone', true)); ?>">
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Password</strong></td>

                                <td>
                                    <a href="<?php echo esc_url(wp_lostpassword_url()); ?>">Reset Password</a>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Title:</strong></td>
                                <td>
                                    <?php echo esc_html(get_user_meta($user_id, 'title', true)); ?>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Total Hunt Day Allocation:</strong></td>
                                <td>
                                    <?php echo esc_html(get_user_meta($user_id, 'hunt_day_allocation', true)); ?>
                                </td>
                            </tr>

                        </table>
                        <button type="submit" name="update_profile" class="btn btn-primary">Update Profile</button>
                    </form>

                <?php else: ?>
                    <div class="alert alert-danger" role="alert">
                        <p>User not found.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>


    </div>
    <script>
        jQuery(document).ready(function ($) {
            $('#phone').on('input', function () {
                var phone = $(this).val();

                // Remove non-digit characters
                phone = phone.replace(/\D/g, '');

                // Restrict to a maximum of 10 digits
                if (phone.length > 10) {
                    phone = phone.slice(0, 10);
                    $(this).val(phone);
                }

                // Display error message if phone number is not valid
                if (phone.length !== 10) {
                    $('#phoneError').text('Please enter a valid 10-digit phone number');
                } else {
                    $('#phoneError').text('');
                }
            });
        });
    </script>

    <?php
}

// Hook the function to the admin menu
add_action('admin_menu', 'add_club_member_menu_item');

?>