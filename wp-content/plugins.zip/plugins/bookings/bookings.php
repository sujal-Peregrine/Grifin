<?php
/*
Plugin Name: Bookings Plugin Plugin
Description: A simple plugin to Bookings Calendar integration.
Version: 1.0
Author: Island
*/
function create_booking_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'booking_data';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id mediumint(9) NOT NULL,
        booking_details text NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

create_booking_table();
function create_waitlist_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'waitlist_data';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id mediumint(9) NOT NULL,
        waitlist_details text NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}




function enqueue_bookings_scripts()
{
    wp_enqueue_style('datatables-css', 'https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css');
    wp_enqueue_style('bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css', array(), '5.3.2');
    wp_enqueue_script('jquery', 'https://code.jquery.com/jquery-3.7.1.min.js', array(), '3.7.1', true);
    wp_enqueue_script('datatables-js', 'https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js', array('jquery'), '1.13.7', true);
    wp_enqueue_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js', array('jquery'), '5.3.2', true);
    wp_enqueue_script('sweetalert2', 'https://cdn.jsdelivr.net/npm/sweetalert2@10', array('jquery'), null, true);
    wp_enqueue_style('sweetalert2', 'https://cdn.jsdelivr.net/npm/sweetalert2@10');
}
add_action('wp_enqueue_scripts', 'enqueue_bookings_scripts');
function my_bookings_menu()
{
    add_menu_page('Bookings', 'Bookings', 'manage_options', 'bookings', 'bookings_page');
}
add_action('admin_menu', 'my_bookings_menu');
function my_bookings_submenu()
{
    add_submenu_page(
        'bookings',        // Parent menu slug
        'Waitlist',        // Page title
        'Waitlist',        // Menu title
        'manage_options',   // Capability required
        'waitlist',        // Menu slug
        'waitlist_page'    // Callback function to display the page content
    );
}
add_action('admin_menu', 'my_bookings_submenu');
function waitlist_page()
{
    ?>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .header {
            background-color: #f4f9ff;
        }

        .table.dataTable {
            width: 100% !important;
        }

        .member-acc {
            padding-top: 10px;
            margin-top: 1rem;
            background-color: #fafafa;
            box-shadow: 0 0 5px #a1a1a114;
        }

        .tabs p {
            padding-top: 6px;
            margin-bottom: 0 !important;
            font-size: 1rem !important;
        }

        h1 {
            font-size: 2rem !important;
            margin-bottom: 1rem !important;
        }

        .title p>input {
            margin-top: 1rem;
            width: 40px;
            height: 25px;
            outline: none;
        }

        h6 {
            font-weight: 400 !important;
            font-size: 1.1rem !important;
            margin-top: 0.6rem !important;
        }

        h6 input {
            padding: 0 5px;
            height: 35px;
            outline: none;
            border-radius: 5px;
            border: 1px solid #c6c6c6 !important;
        }

        #myTable span {
            color: #58adf9;
        }

        .manage-booking {
            background-color: #fafafa;
        }

        #myTable th {
            padding: 10px;
            font-size: 15px;
            font-weight: 400;
            color: #545454;
            text-transform: capitalize !important;
        }

        td {
            color: #616060;
            font-weight: 400;
            font-size: 14px;
            padding: 10px;
        }

        .buttons {
            padding-left: 12px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled,
        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled:hover,
        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled:active {
            border: 1px solid #8b8b8b;
            padding: 6px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            margin-left: 12px !important;
            border: 1px solid #8b8b8b;
            border-radius: 5px;
            padding: 6px 12px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            color: #8b8b8b !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            color: #fff !important;
            background-color: #007bff !important;
        }

        .card {
            min-width: 100% !important;
            padding: 0;
        }

        hr {
            opacity: 0.1;
        }

        .btn-hover:hover {
            color: white !important;
        }

        #myTable_paginate {
            position: absolute;
            bottom: 4%;
            right: 2%;
        }

        .table-card {
            width: 100%;
            overflow-y: auto;
            /* Add this to enable horizontal scrolling if needed */
        }
        .dataTables_wrapper div.dataTables_paginate {
            position: relative !important;
            top: -18px !important;
        }
    </style>
    <div class="card w-100">
        <div class="card-header pb-0 w-100">
            <h3>Manage Waitlist</h3>
        </div>
        <div class="card-body pt-0">
            <div>
                <div class="table-responsive-waitlist table-card mb-1">
                    <table class="table table-nowrap align-middle" id="myDatatableWaitlist">
                        <thead class="text-muted table-light">
                            <tr class="text-uppercase">
                                <th class="sort" data-sort="id"> ID</th>
                                <th class="sort" data-sort="customer_name">Member</th>
                                <th style="width:185px" class="sort" data-sort="status">Number of guests </th>
                                <th class="sort" data-sort="status">Preferred Date</th>
                            </tr>
                        </thead>
                        <tbody class="border-1">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script>
        jQuery(document).ready(function ($) {
            let adminUrl = '<?php echo admin_url('admin.php?page=view_member_page&user_id='); ?>';
            let dataTableWaitlist = $('#myDatatableWaitlist').DataTable({
                order: [[0, 'desc']],
                columns: [
                    { data: 'id' },
                    {
                        data: 'user_nicename',
                        render: function (data, type, row) {
                            const waitlistDetails = JSON.parse(row.waitlist_details);
                            const link = '<a href="' + adminUrl + waitlistDetails.member + '">' + data + '</a>';
                            return link;
                        }
                    },
                    {
                        data: 'waitlist_details',
                        render: function (data, type, row) {
                            const waitlistDetails = JSON.parse(data);
                            return waitlistDetails.number_of_hunters;
                        }
                    },
                    {
                        data: 'waitlist_details',
                        render: function (data, type, row) {
                            const waitlistDetails = JSON.parse(data);
                            return waitlistDetails.prefered_date;
                        }
                    }
                ]
            });
            loadWaitlistData();
            function loadWaitlistData() {
                $.ajax({
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    type: 'POST',
                    data: {
                        action: 'get_waitlist_data',
                        security: '<?php echo wp_create_nonce('waitlist_nonce'); ?>'
                    },
                    success: function (response) {
                        console.log(response);
                        dataTableWaitlist.clear().draw();
                        if (response.length > 0) {
                            $.each(response, function (index, waitlist) {
                                waitlist.user_nicename = waitlist.user_nicename || '';
                                waitlist.number_of_hunters = waitlist.waitlist_details ? JSON.parse(waitlist.waitlist_details).number_of_hunters : '';
                                waitlist.prefered_date = waitlist.waitlist_details ? JSON.parse(waitlist.waitlist_details).prefered_date : '';
                                dataTableWaitlist.row.add(waitlist).draw(false);
                            });
                        } else {
                        }
                    },
                    error: function (xhr, status, error) {
                    }
                });
            }
        });
    </script>
    <?php
}
function bookings_page()
{
    wp_enqueue_script('sweetalert2', 'https://cdn.jsdelivr.net/npm/sweetalert2@10', array('jquery'), null, true);
    wp_enqueue_style('sweetalert2', 'https://cdn.jsdelivr.net/npm/sweetalert2@10');
    ?>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .header {
            background-color: #f4f9ff;
        }

        .table.dataTable {
            width: 100% !important;
        }

        .member-acc {
            padding-top: 10px;
            margin-top: 1rem;
            background-color: #fafafa;
            box-shadow: 0 0 5px #a1a1a114;
        }

        .tabs p {
            padding-top: 6px;
            margin-bottom: 0 !important;
            font-size: 1rem !important;
        }

        h1 {
            font-size: 2rem !important;
            margin-bottom: 1rem !important;
        }

        .title p>input {
            margin-top: 1rem;
            width: 40px;
            height: 25px;
            outline: none;
        }

        h6 {
            font-weight: 400 !important;
            font-size: 1.1rem !important;
            margin-top: 0.6rem !important;
        }

        h6 input {
            padding: 0 5px;
            height: 35px;
            outline: none;
            border-radius: 5px;
            border: 1px solid #c6c6c6 !important;
        }

        #myTable span {
            color: #58adf9;
        }

        .manage-booking {
            background-color: #fafafa;
        }

        #myTable th {
            padding: 10px;
            font-size: 15px;
            font-weight: 400;
            color: #545454;
            text-transform: capitalize !important;
        }

        td {
            color: #616060;
            font-weight: 400;
            font-size: 14px;
            padding: 10px;
        }

        .buttons {
            padding-left: 12px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled,
        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled:hover,
        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled:active {
            border: 1px solid #8b8b8b;
            padding: 6px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            margin-left: 12px !important;
            border: 1px solid #8b8b8b;
            border-radius: 5px;
            padding: 6px 12px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            color: #8b8b8b !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            color: #fff !important;
            background-color: #007bff !important;
        }

        .card {
            min-width: 100% !important;
            padding: 0;
        }

        hr {
            opacity: 0.1;
        }

        .btn-hover:hover {
            color: white !important;
        }

        #myTable_paginate {
            position: absolute;
            bottom: 4%;
            right: 2%;
        }

        .nav-tabs .nav-link.active,
        .nav-tabs .nav-item.show .nav-link {
            position: relative;
            color: #67b173 !important;
            background-color: transparent !important;
            border-color: transparent !important;
            transition-timing-function: 0.5s ease-in;
        }

        .nav-link.active::after {
            content: "";
            position: absolute;
            bottom: -6px;
            left: 0;
            width: 100%;
            height: 1px;
            background-color: #67b173;
            transition-timing-function: 0.5s ease-in;
        }

        .nav-link:focus,
        .nav-link:hover {
            border: none !important;
            color: #3d78e3 !important;
            background-color: transparent !important;
        }

        .nav-tabs .nav-link {
            margin-bottom: calc(-1 * var(--vz-nav-tabs-border-width));
            border: none !important;
            border-top-left-radius: var(--vz-nav-tabs-border-radius);
            border-top-right-radius: var(--vz-nav-tabs-border-radius);
        }

        .nav-link {
            color: #000 !important;
        }

        .table-card {
            margin-top: -6px;
        }

        .badge {
            background-color: transparent !important;
        }



        .line-height {
     
            font-size: 16px !important;
        }
        /* Ṛuchit */
        #no-guest{
            width: 185px !important;
        }
    </style>
    <div class="card w-100">
        <div class="card-header pb-0 w-100">
            <h3>Manage Bookings</h3>
        </div>
        <hr>
        <div class="card-body px-0">
            <div class="card-body px-0 pt-0">
                <div>
                    <ul class="nav nav-tabs nav-tabs-custom nav-success " role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link  All active " data-bs-toggle="tab" id="All" role="tab"
                                aria-selected="false" tabindex="-1">
                                All
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link  Pending text-dark  btn btn-warning  " data-bs-toggle="tab" id="Pending"
                                role="tab" aria-selected="false" tabindex="-1">
                                Pending
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link  Cancelled text-dark  btn btn-secondary" data-bs-toggle="tab"
                                id="Cancelled" role="tab" aria-selected="false" tabindex="-1">
                                Cancelled
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link  Approved text-dark  btn btn-success" data-bs-toggle="tab" id="Approved"
                                role="tab" aria-selected="false" tabindex="-1">
                                Approved
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link  Declined text-dark  btn btn-danger" data-bs-toggle="tab" id="Declined"
                                role="tab" aria-selected="false" tabindex="-1">
                                Declined
                            </button>
                        </li>
                    </ul>
                    <div class="table-responsive table-card mb-1">
                        <table class="table table-nowrap align-middle" id="myTable">
                            <thead class="text-muted table-light">
                                <tr class="text-uppercase">
                                    <th class="sort" data-sort="id"> ID</th>
                                    <th class="sort" data-sort="customer_name">Member</th>
                                    <th class="sort" data-sort="product_name">Requested</th>
                                    <th class="sort" data-sort="date">Start date</th>
                                    <th class="sort" data-sort="amount">End date</th>
                                  <!--Ruchit -->  <th style="width:185px" id="no-guest" class="sort" data-sort="status">Number of guests </th>
                                  <th class="sort" data-sort="editStatus">Status</th>
                                </tr>
                            </thead>
                            <tbody class="border-1">
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        jQuery(document).ready(function ($) {
            let adminUrl = '<?php echo admin_url('admin.php?page=view_member_page&user_id='); ?>';

            let dataTable = $('#myTable').DataTable({
                order: [[0, 'desc']],

                searching: false,
                lengthChange: false,
                columns: [
                    { data: 'id' },       {
                        data: 'member',
                        render: function (data, type, row) {
                            const link = '<a href="' + adminUrl + row.user_id + '">' + data + '</a>';
                            return link;
                        }
                    },
                    { data: 'requested_Date' },
                    { data: 'start_date' },
                    { data: 'end_date' },
                    { data: 'numberOfGuests' },
                    {
                        data: 'status',
                        render: function (data, type, row) {
                            const selectOptions = `
                                <option value="Approved" class="badge line-height bg-success-subtle text-uppercase text-success" ${data === 'Approved' ? 'selected' : ''}>Approved</option>
                                <option value="Pending" class="badge line-height bg-warning-subtle text-uppercase text-warning" ${data === 'Pending' ? 'selected' : ''}>Pending</option>
                                <option value="Cancelled" class="badge line-height  bg-secondary-subtle text-uppercase text-secondary" ${data === 'Cancelled' ? 'selected' : ''}>Cancelled</option>
                                <option value="Declined" class="badge line-height bg-danger-subtle text-uppercase text-danger" ${data === 'Declined' ? 'selected' : ''}>Declined</option>
                            `;

                            return `<div > <select class=" form-select form-select-lg status-dropdown badge ${getStatusClass(data)}" data-booking-id="${row.id}" onchange="updateStatusClass(this)">
                                ${selectOptions}
                            </select> </div> `;
                        }
                    }
                ]
            });

            function getStatusClass(status) {
                switch (status) {
                    case 'Approved':
                        return 'bg-success-subtle text-success';
                    case 'Pending':
                        return 'bg-warning-subtle text-warning';
                    case 'Cancelled':
                        return 'bg-secondary-subtle text-secondary';
                    case 'Declined':
                        return 'bg-danger-subtle text-danger';
                    default:
                        return '';
                }
            }

            function updateStatusClass(selectElement) {
                const selectedOption = selectElement.options[selectElement.selectedIndex];
                const statusClass = getStatusClass(selectedOption.value);

                // Remove existing classes and add the new class
                selectElement.className = selectElement.className.replace(/bg-\w+-subtle text-\w+/, '').trim();
                selectElement.classList.add(statusClass);
            }

            loadBookingData('All');
            function loadBookingData(status) {
                $.ajax({
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    type: 'POST',
                    data: {
                        action: 'get_booking_data',
                        status: status,
                    },
                    success: function (response) {
                        dataTable.clear().draw();
                        if (response.length > 0) {
                            $.each(response, function (index, booking) {
                                dataTable.row.add(booking).draw(false);
                            });
                            $('.status-dropdown').on('change', function () {
                                const bookingId = $(this).data('booking-id');
                                const newStatus = $(this).val();
                                const previousStatus = $(this).val();

                                Swal.fire({
                                    title: 'Are you sure?',
                                    text: 'Do you really want to update the status?',
                                    icon: 'warning',
                                    showCancelButton: true,
                                    confirmButtonColor: '#3085d6',
                                    cancelButtonColor: '#d33',
                                    confirmButtonText: 'Yes, update it!'
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        updateBookingStatus(bookingId, newStatus);
                                    } else {
                                        $(this).val(previousStatus);
                                        loadBookingData('All');
                                        $('#All').addClass('active').trigger('click');

                                    }
                                });
                            });
                        } else {
                        }
                    },
                    error: function (xhr, status, error) {
                    },
                });
            }
            function updateBookingStatus(bookingId, newStatus) {
                $.ajax({
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    type: 'POST',
                    data: {
                        action: 'update_booking_status',
                        booking_id: bookingId,
                        new_status: newStatus,
                    },
                    success: function (response) {
                        Swal.fire({
                            title: 'Success!',
                            text: 'Status Updated',
                            icon: 'success',
                            confirmButtonText: 'OK'
                        }).then(function () {
                            loadBookingData('All');
                            $('.nav-tabs-custom .nav-link.active').removeClass('active');
                            $('#All').addClass('active').trigger('click');
                        });
                    },
                    error: function (xhr, status, error) {
                    },
                });
            }
            function getStatusLabel(status) {
                switch (status) {
                    case 'Cancelled':
                        return '<span class="badge bg-secondary-subtle text-secondary text-uppercase">Cancelled</span>';
                    case 'Approved':
                        return '<span class="badge bg-success-subtle text-uppercase text-success">Approved</span>';
                    case 'Pending':
                        return '<span class="badge bg-warning-subtle text-uppercase text-warning">Pending</span>';
                    case 'Declined':
                        return '<span class="badge bg-danger-subtle text-uppercase text-danger">Declined</span>';
                    default:
                        return '<span style="color: red;">null</span>';
                }
            }
            $('.nav-tabs-custom button').on('click', function (e) {
                e.preventDefault();
                let status = $(this).attr('id');
                loadBookingData(status);
            });
        });
    </script>
    <?php
}
add_action('wp_ajax_get_booking_data', 'get_booking_data');
add_action('wp_ajax_nopriv_get_booking_data', 'get_booking_data');
function get_booking_data()
{
    global $wpdb;
    $status_map = array(
        'All' => '',
        'Cancelled' => '4',
        'Approved' => '1',
        'Pending' => '2',
        'Declined' => '3',
    );
    $status = isset($_POST['status']) ? $_POST['status'] : 'All';
    $status_value = isset($status_map[$status]) ? $status_map[$status] : '';
    $table_name = $wpdb->prefix . 'booking_data';
    $users_table_name = $wpdb->prefix . 'users';
    $sql = empty($status_value) ?
    "SELECT booking.*, users.user_nicename FROM $table_name as booking LEFT JOIN $users_table_name as users ON CAST(JSON_UNQUOTE(JSON_EXTRACT(booking.booking_details, '$.member')) AS UNSIGNED) = users.ID ORDER BY booking.created_at DESC" :
    $wpdb->prepare("SELECT booking.*, users.user_nicename FROM $table_name as booking LEFT JOIN $users_table_name as users ON CAST(JSON_UNQUOTE(JSON_EXTRACT(booking.booking_details, '$.member')) AS UNSIGNED) = users.ID WHERE booking.booking_details LIKE %s ORDER BY booking.created_at DESC", '%"status":"' . $status_value . '"%');
$booking_data = $wpdb->get_results($sql);
    $response = array();
    foreach ($booking_data as $booking) {
        $booking_details = json_decode($booking->booking_details, true);
        $dateRange =  $booking_details['datePicker'];
        $dateRangeArray = explode(',', $dateRange);

// Extract start date (first element of the array)
$startDate = reset($dateRangeArray); // Returns the first element of the array

// Extract end date (last element of the array)
$endDate = end($dateRangeArray);


// If $endDate is not present, set it to $startDate
if (empty($endDate)) {
    $endDate = $startDate;
}

        $response[] = array(
            'id' => isset($booking->id) ? esc_html($booking->id) : null,
            'member' => isset($booking->user_nicename) ? esc_html($booking->user_nicename) : null,
            'user_id' => isset($booking->user_id) ? esc_html($booking->user_id) : null,
            'requested_Date' => isset($booking->created_at) ? date('F j Y', strtotime($booking->created_at)) : null,
            'start_date' => isset($startDate) ? date('F j Y', strtotime($startDate)) : null,
            'end_date' => isset($endDate) ? date('F j Y', strtotime($endDate)) : null,
            'numberOfGuests' => isset($booking_details['numberOfGuests']) ? esc_html($booking_details['numberOfGuests']) : null,
            'status' => empty($status_value) ? get_status_label($booking_details['status']) : get_status_label($status_value),
        );
    }
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}
function get_status_label($status)
{
    switch ($status) {
        case 4:
            return 'Cancelled';
        case 1:
            return 'Approved';
        case 2:
            return 'Pending';
        case 3:
            return 'Declined';
        default:
            return null;
    }
}
function update_booking_status()
{
    global $wpdb;
    $booking_id = isset($_POST['booking_id']) ? $_POST['booking_id'] : '';
    $new_status = isset($_POST['new_status']) ? $_POST['new_status'] : '';
    $status_map = array(
        'Cancelled' => '4',
        'Approved' => '1',
        'Pending' => '2',
        'Declined' => '3',
    );
    if (!empty($booking_id) && !empty($new_status) && isset($status_map[$new_status])) {
        $table_name = $wpdb->prefix . 'booking_data';
        $existing_details = $wpdb->get_var($wpdb->prepare("SELECT booking_details FROM $table_name WHERE id = %d", $booking_id));
        if ($existing_details) {
            $booking_details = json_decode($existing_details, true);
            $booking_details['status'] = $status_map[$new_status];
            $updated_details = json_encode($booking_details);
            $wpdb->update(
                $table_name,
                array('booking_details' => $updated_details),
                array('id' => $booking_id)
            );
            echo json_encode(array('success' => true));
        } else {
            echo json_encode(array('error' => 'Booking details not found'));
        }
    } else {
        echo json_encode(array('error' => 'Invalid parameters'));
    }
    exit;
}
add_action('wp_ajax_update_booking_status', 'update_booking_status');
add_action('wp_ajax_get_waitlist_data', 'get_waitlist_data');
add_action('wp_ajax_nopriv_get_waitlist_data', 'get_waitlist_data');
function get_waitlist_data()
{
    global $wpdb;
    $waitlist_table_name = $wpdb->prefix . 'waitlist_data';
    $users_table_name = $wpdb->prefix . 'users';
    $waitlist_data = $wpdb->get_results("
        SELECT waitlist.*, users.user_nicename
        FROM $waitlist_table_name as waitlist
        LEFT JOIN $users_table_name as users ON CAST(JSON_UNQUOTE(JSON_EXTRACT(waitlist.waitlist_details, '$.member')) AS UNSIGNED) = users.ID
    ", ARRAY_A);
    wp_send_json($waitlist_data);
}
